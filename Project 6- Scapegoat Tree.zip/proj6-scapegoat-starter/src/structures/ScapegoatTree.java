package structures;

public class ScapegoatTree<T extends Comparable<T>> extends BinarySearchTree<T> {
  private int upperBound;


  @Override
  public void add(T t) {
    // TODO: Implement the add() method
    upperBound++;
    super.add(t);
    if(height() > ( Math.log(size()) / Math.log(3/2) ) + 2){

    }
    

  }

  @Override
  public boolean remove(T element) {
    // TODO: Implement the remove() method
    if(element == null){
      throw new NullPointerException();
    }
    boolean exists = super.remove(element);
    int size = size();
    if(upperBound>2*size){
      balance();
      upperBound = size();
    }
    return exists;
    
  }

  public static void main(String[] args) {
    BSTInterface<String> tree = new ScapegoatTree<String>();
    /*
    You can test your Scapegoat tree here.
    */
    for (String r : new String[] {"0", "1", "2", "3", "4"}) {
      tree.add(r);
      System.out.println(toDotFormat(tree.getRoot()));
    }
  }
}
