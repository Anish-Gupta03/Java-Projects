package app;

public enum Condition {
  LIGHT, MILD, SEVERE, CRITICAL
}
