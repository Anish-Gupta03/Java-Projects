package stack;

/**
 * A {@link LinkedStack} is a stack that is implemented using a Linked List structure to allow for
 * unbounded size.
 *
 * @param <T> the elements stored in the stack
 */
public class LinkedStack<T> implements StackInterface<T> {
  private LLNode<T> head= null;

  /** {@inheritDoc} */
  @Override
  public T pop() throws StackUnderflowException {
    // TODO: Implement the stack operation for `pop`!
    LLNode<T> temp;
    if(head == null){
      throw new StackUnderflowException();
    }else{
      temp = head;
      head = head.getNext();
    }
    return temp.getData();
  }

  /** {@inheritDoc} */
  @Override
  public T top() throws StackUnderflowException {
    // TODO: Implement the stack operation for `top`!
    if(head == null){
      throw new StackUnderflowException();
    }
    return head.getData();
  }

  /** {@inheritDoc} */
  @Override
  public boolean isEmpty() {
    // TODO: Implement the stack operation for `isEmpty`!
    boolean empty = false;
    if(head == null){
      empty = true;;
    }
    return empty;
  }

  /** {@inheritDoc} */
  @Override
  public int size() {
    // TODO: Implement the stack operation for `size`!
    int count = 0;
    LLNode<T> temp = head;
    while(temp != null){
      count++;
      temp = temp.getNext();
    }
    return count;
  }

  /** {@inheritDoc} */
  @Override
  public void push(T elem) {
    // TODO: Implement the stack operation for `push`!
    LLNode<T> val = new LLNode<T>(elem);
    val.setNext(head);
    head = val;
  }
}
