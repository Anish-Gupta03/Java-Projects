package evaluator.arith;

import language.Operand;
import language.Operator;
import language.arith.DivOperator;
import language.arith.MultOperator;
import language.arith.NegateOperator;
import language.arith.PlusOperator;
import language.arith.SubOperator;
import parser.IllegalPostfixExpressionException;
import parser.PostfixParser.Type;
import parser.Token;
import parser.arith.ArithPostfixParser;
import stack.LinkedStack;
import stack.StackInterface;
import evaluator.PostfixEvaluator;

/** An {@link ArithPostfixEvaluator} is a postfix evaluator over simple arithmetic expressions. */
public class ArithPostfixEvaluator implements PostfixEvaluator<Integer> {

  private final StackInterface<Operand<Integer>> stack;

  /** Constructs an {@link ArithPostfixEvaluator} */
  public ArithPostfixEvaluator() {
    // TODO Initialize to your LinkedStack
    stack = new LinkedStack<Operand<Integer>>();
  }

  /** {@inheritDoc} */
  @Override
  public Integer evaluate(String expr) throws IllegalPostfixExpressionException {
    while(stack.size() !=0){
      stack.pop();
    }
    ArithPostfixParser parser = new ArithPostfixParser(expr);
    for (Token<Integer> token : parser) {
      Type type = token.getType();
      //push all of the operands onto the stack and then when you see the operators, pop off the 2 items on the top 
      //of the stack and do the operation on them and then push them back on the stack. 
      //Then do this for all operators
      switch (type) {
        case OPERAND:
          // TODO What do we do when we see an operand?
          Operand<Integer> val = token.getOperand();
          stack.push(val);
          break;
        case OPERATOR:
          // TODO What do we do when we see an operator?
          Operator<Integer> op;
          if(token.getOperator().toString() == "/"){
            op = new DivOperator();
            Operand<Integer> val1 = stack.pop();
            Operand<Integer> val2 = stack.pop();
            op.setOperand(1, val1);
            op.setOperand(0, val2);
            stack.push(op.performOperation());

          }
          if(token.getOperator().toString() == "*"){
            op = new MultOperator();
            Operand<Integer> val1 = stack.pop();
            Operand<Integer> val2 = stack.pop();
            op.setOperand(0, val1);
            op.setOperand(1, val2);
            stack.push(op.performOperation());
          }
          if(token.getOperator().toString() == "!"){
            op = new NegateOperator();
            Operand<Integer> val1 = stack.pop();
            op.setOperand(0, val1);
            stack.push(op.performOperation());
          }
          if(token.getOperator().toString() == "+"){
            op = new PlusOperator();
            Operand<Integer> val1 = stack.pop();
            Operand<Integer> val2 = stack.pop();
            op.setOperand(0, val1);
            op.setOperand(1, val2);
            stack.push(op.performOperation());
          }
          if(token.getOperator().toString() == "-"){
            op = new SubOperator();
            Operand<Integer> val1 = stack.pop();
            Operand<Integer> val2 = stack.pop();
            op.setOperand(1, val1);
            op.setOperand(0, val2);
            stack.push(op.performOperation());
          }
          break;
        default:
          throw new IllegalStateException("Parser returned an invalid Type: " + type);
      }
    }
    // TODO What do we return?
    if(stack.size() != 1){
      throw new IllegalPostfixExpressionException();
    }
    return stack.top().getValue();
  }
}
