package graph;
import java.util.ArrayList;
/**
 * This class implements general operations on a graph as specified by UndirectedGraphADT.
 * It implements a graph where data is contained in Vertex class instances.
 * Edges between verticies are unweighted and undirected.
 * A graph coloring algorithm determines the chromatic number. 
 * Colors are represented by integers. 
 * The maximum number of vertices and colors must be specified when the graph is instantiated.
 * You may implement the graph in the manner you choose. See instructions and course material for background.
 */
 
 public class UndirectedUnweightedGraph<T> implements UndirectedGraphADT<T> {
   // private class variables here.
   
   private int MAX_VERTICES;
   private int MAX_COLORS;
    // TODO: Declare class variables here.
   private ArrayList<Vertex<T>> vertices;
   //private ArrayList<Integer> colors;
   private boolean adjacencyTable[][];

   
   /**
    * Initialize all class variables and data structures. 
   */   
   public UndirectedUnweightedGraph (int maxVertices, int maxColors){
      MAX_VERTICES = maxVertices;
      MAX_COLORS = maxColors; 
     // TODO: Implement the rest of this method.
     vertices = new ArrayList<Vertex<T>>();
     //colors = new ArrayList<Integer>();
     adjacencyTable = new boolean[MAX_VERTICES][MAX_VERTICES];

   }

   /**
    * Add a vertex containing this data to the graph.
    * Throws Exception if trying to add more than the max number of vertices.
   */
   public void addVertex(T data) throws Exception {
    // TODO: Implement this method.
    if(vertices.size() == MAX_VERTICES) throw new Exception();
    Vertex<T> newData = new <T> Vertex(data);
    vertices.add(newData);
   }
   
   /**
    * Return true if the graph contains a vertex with this data, false otherwise.
   */   
   public boolean hasVertex(T data){
    // TODO: Implement this method.
    for(int i=0; i<vertices.size(); i++){
      if(vertices.get(i).getData().equals(data)) return true;
    }
      return false;
   } 

   /**
    * Add an edge between the vertices that contain these data.
    * Throws Exception if one or both vertices do not exist.
   */   
   public void addEdge(T data1, T data2) throws Exception{
    // TODO: Implement this method.
    if(hasVertex(data1) == false || hasVertex(data2) == false) throw new Exception();
    int verticeIndex1 = 0;
    int verticeIndex2 = 0;
    for(int i=0; i<vertices.size(); i++){
      if(vertices.get(i).getData().equals(data1)) verticeIndex1 = i;
      if(vertices.get(i).getData().equals(data2)) verticeIndex2 = i;
    }
    adjacencyTable[verticeIndex1][verticeIndex2] = true;
    adjacencyTable[verticeIndex2][verticeIndex1] = true;


   }

   /**
    * Get an ArrayList of the data contained in all vertices adjacent to the vertex that
    * contains the data passed in. Returns an ArrayList of zero length if no adjacencies exist in the graph.
    * Throws Exception if a vertex containing the data passed in does not exist.
   */   
   public ArrayList<T> getAdjacentData(T data) throws Exception{
    // TODO: Implement this method.
    if(hasVertex(data) == false) throw new Exception();
    ArrayList<T> adjacentVertices = new ArrayList<T>();
    int index = 0;
    for(int i =0; i<vertices.size(); i++){
      if(vertices.get(i).getData().equals(data)) index = i;
    }

    for(int i = 0; i<vertices.size(); i++){
      if(adjacencyTable[index][i]) adjacentVertices.add(vertices.get(i).getData());
    }

      return adjacentVertices;
   }
   
   /**
    * Returns the total number of vertices in the graph.
   */   
   public int getNumVertices(){
    // TODO: Implement this method.
      return vertices.size();
   }

   /**
    * Returns the total number of edges in the graph.
   */   
   public int getNumEdges(){
    // TODO: Implement this method.
    int count = 0;
    for(int i=0; i<adjacencyTable.length; i++){
      for(int j=0; j<adjacencyTable.length; j++){
        if(adjacencyTable[i][j]) count++;
      }
    }
    count = count/2;
      return count;
   }

   /**
    * Returns the minimum number of colors required for this graph as 
    * determined by a graph coloring algorithm.
    * Throws an Exception if more than the maximum number of colors are required
    * to color this graph.
   */   
   public int getChromaticNumber() throws Exception{
    // TODO: Implement this method.
    int highestColorUsed = -1;
    int colorToUse = -1;
    for(int i=0; i<vertices.size(); i++){
      if(vertices.get(i).getColor() == -1){
        colorToUse = getColorToUse(vertices.get(i));
        vertices.get(i).setColor(colorToUse);
        if(colorToUse > highestColorUsed) highestColorUsed++;
      }
    }
      return highestColorUsed;
   }
   
   private int getColorToUse(Vertex<T> curVertex) throws Exception{
     int colorToUse = -1;
     boolean[] adjColorsUsed = new boolean[MAX_COLORS];
     ArrayList<Vertex<T>> adjVertsList = getAdjacentVertices(curVertex);
     for(int i=0; i<adjVertsList.size(); i++){
       if(adjVertsList.get(i).getColor() != -1) adjColorsUsed[i] = true;
     }
     for(int i=0; i<adjColorsUsed.length; i++){
       if(adjColorsUsed[i] == false){
         colorToUse = i+1;
         break;
       }
     }
     if(colorToUse == -1){
      throw new Exception();
     }
     else{
       return colorToUse;
     }
   }

   private ArrayList<Vertex<T>> getAdjacentVertices(Vertex<T> curVertex) throws Exception{
    if(hasVertex(curVertex.getData()) == false) throw new Exception();
    ArrayList<Vertex<T>> adjacentVertices = new ArrayList<Vertex<T>>();
    int index = 0;
    for(int i =0; i<vertices.size(); i++){
      if(vertices.get(i).getData().equals(curVertex.getData())) index = i;
    }

    for(int i = 0; i<vertices.size(); i++){
      if(adjacencyTable[index][i]) adjacentVertices.add(vertices.get(i));
    }

    return adjacentVertices;
   }
   
}