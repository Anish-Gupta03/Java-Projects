package test;

import static org.junit.Assert.*;

import app.*;
import org.junit.Before;
import org.junit.Test;


public class ProjectTests {

	private ListInterface<String> list;

	@Before
	public void setup() {
		list = new RecursiveList<String>();
	}

	@Test
	public void testInsertFirstIsEmptySizeAndGetFirst1() {
		assertTrue("Newly constructed list should be empty.", list.isEmpty());
	}

	@Test
	public void testInsertFirstIsEmptySizeAndGetFirst3() {
		assertTrue("Newly constructed list should be empty.", list.isEmpty());
		assertEquals("Newly constructed list should be size 0.", 0, list.size());
		list.insertFirst("hello");
		assertEquals("Inserted and then got an element at the first position", "hello", list.getFirst());
	}

	@Test(timeout = 500, expected = IllegalStateException.class)
	public void testExceptionOnEmptyGetLast() {
		list.getLast();
	}

	@Test
	public void testItemNotFoundExceptionOnRemove() {
		list.insertFirst("hello");
		list.remove("there");
	}

	@Test
	public void testInsertsGetsRemovesSize() {
		assertTrue("Newly constructed list should be empty.", list.isEmpty());
		list.insertLast("Hello");
		list.insertLast("World!");
		list.insertAt(1, "There");

		assertEquals("Checking position 1.", "There", list.get(1));

		assertEquals("Size should be 3", 3, list.size());
		assertEquals("0th element should .equals \"Hello\"", "Hello", list.get(0));
		assertEquals("Last element should .equals \"World!\"", "World!", list.getLast());
		list.insertAt(0, "foo");
		list.insertAt(4, "bar");
		assertEquals("foo", list.get(0));
		assertEquals("bar", list.get(4));
		assertEquals("Size should be 5", 5, list.size());
		assertEquals("The third element should have been \"World!\"", "World!", list.removeAt(3));
		assertEquals("Size should be 4", 4, list.size());
		assertEquals("Last element should be \"bar\"", "bar", list.getLast());
	}
	@Test
	public void testGetLast(){
		list.insertFirst("1");
		list.insertFirst("2");
		list.insertFirst("4");
		list.insertFirst("5");
		list.insertFirst("6");
		list.insertFirst("7");
		list.getLast();
		assertEquals("1", list.getLast());

	}
	@Test
	public void testRemoveLast(){
		list.insertFirst("1");
		list.insertFirst("2");
		list.insertFirst("3");
		list.removeLast();
		assertEquals("2", list.getLast());
	}
	@Test
	public void testInsertLast(){
		list.insertFirst("1");
		list.insertFirst("2");
		list.insertFirst("3");
		list.insertLast("0");
		list.insertLast("5");
		assertEquals("5", list.getLast());
	}
	@Test
	public void testInsertAt(){
		list.insertFirst("1");
		list.insertFirst("2");
		list.insertFirst("3");
		list.insertAt(3, "4");
		assertEquals("4", list.getLast());
	}
	@Test
	public void testGet(){
		list.insertFirst("1");
		list.insertFirst("2");
		list.insertFirst("4");
		list.insertFirst("5");
		list.insertFirst("6");
		list.insertFirst("7");
		assertEquals("1", list.get(5));
	}

	@Test
	public void testIndexOf(){
		list.insertFirst("1");
		list.insertFirst("1");
		list.insertFirst("2");
		list.insertFirst("3");
		list.indexOf("4");
		assertEquals(1, list.indexOf("2"));
	}

}
