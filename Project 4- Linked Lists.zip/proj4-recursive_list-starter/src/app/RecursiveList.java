package app;

import java.util.Iterator;

public class RecursiveList<T> implements ListInterface<T> {

  private int size;
  private Node<T> head = null;



  public RecursiveList() {
    this.head = null;
    this.size = 0;
  }

  public RecursiveList(Node<T> first) {
    this.head = first;
    this.size = 1;
  }

  @Override
  public int size() {
    return size;
  }

  @Override
  public void insertFirst(T elem) {
      if(elem == null){
        throw new NullPointerException();
      }
      Node<T> newHead = new Node<T>(elem, head);
      head = newHead;
      size++;
  }

  @Override
  public void insertLast(T elem) {
      if(elem == null){
        throw new NullPointerException();
      }
      if(head == null){
        Node<T> cur = new Node<T>(elem, null);
        head = cur;
      }else{
        Node<T> newLast = new Node<T>(elem, null);
        Node<T> temp = insertLastHelper(head);
        temp.setNext(newLast);
      }
      size++;
      
  }

  
  //My helper method for insert Last
  private Node<T> insertLastHelper(Node<T> temporary){
    if(temporary.getNext() != null){
      return insertLastHelper(temporary.getNext());
    }
    return temporary;
  }


  @Override
  public void insertAt(int index, T elem) {
      if(elem == null){
        throw new NullPointerException();
      }
      if(index<0 || index> size){
        throw new IndexOutOfBoundsException();
      }

      Node<T> insertion = new Node<T>(elem, null);
      if(index == 0){
        insertion.setNext(head);
        head = insertion;
      }else{
        Node<T> temp = insertAtHelper(head, index, 0);
        Node<T> precNode = getPrec(head, index, 0);
        precNode.setNext(insertion);
        if(index == size){
          insertion.setNext(null);
        }else{
          insertion.setNext(temp);
        }
    }
      size++;
  }
  private Node<T> insertAtHelper(Node<T> start, int i, int cur){
    if(cur != i){
      start = start.getNext();
      return removeAtHelper(start, i, cur+1);
    }
    return start;
  }

  @Override
  public T removeFirst() {
    T removedItem = getFirst();
    Node<T> tempData = new Node<T>(removedItem, head.getNext());
    head = tempData.getNext();
    size--;
    return removedItem;
  }

  @Override
  public T removeLast() {
    T removedItem = getLast();
    //TODO: Implement this method.
    if(head.getNext() == null){
      head = null;
    }else{
      Node<T> secondToLast = removeLastHelper(head, size, 0);
      secondToLast.setNext(null);
    }
    size--;
    return removedItem;
  }

  private Node<T> removeLastHelper(Node<T> start, int listSize, int cur){
    if(cur != listSize-2){
      return removeLastHelper(start.getNext(), listSize, cur+1);
    }
    return start;
  }

  @Override
  public T removeAt(int i) {
      if(i<0 || i>= size){
        throw new IndexOutOfBoundsException();
      }
      if(i == 0){
        removeFirst();
      }
      Node<T> temp = removeAtHelper(head, i, 0);
      Node<T> precNode = getPrec(head, i, 0);
      Node<T> sucNode = getSuc(head, i, 0);
      precNode.setNext(sucNode);
      size--;


    return temp.getData();
  }

  private Node<T> removeAtHelper(Node<T> start, int i, int cur){
    if(cur != i){
      start = start.getNext();
      return removeAtHelper(start, i, cur+1);
    }
    return start;

  }
  private Node<T> getPrec(Node<T> start, int i, int cur){
    if(cur != i-1){
      start = start.getNext();
      return getPrec(start, i, cur+1);
    }
    return start;
  }
  private Node<T> getSuc(Node<T> start, int i, int cur){
    if(cur != i+1){
      start = start.getNext();
      return getSuc(start, i, cur+1);
    }
    return start;
  }

  @Override
  public T getFirst() {
    if(head == null){
      throw new IllegalStateException();
    }
    T item = head.getData();
    return item;
  }

  @Override
  public T getLast() {
    if(head == null){
      throw new IllegalStateException();
    }
    Node<T> temp = head;
    temp = getLastHelper(temp);
    return temp.getData();
  }

  private Node<T> getLastHelper(Node<T> temporary){
    if(temporary.getNext() != null){
      temporary = temporary.getNext();
      return getLastHelper(temporary);
    }
    return temporary;
  }

  @Override
  public T get(int i) {
    T item = null;
      //TODO: Implement this method.
    if(i<0 || i>=size){
      throw new IndexOutOfBoundsException();
    }
    Node<T> temp = getHelper(head, i, 0);
    item = temp.getData();
    return item;
  }
  
  private Node<T> getHelper(Node<T> start, int index, int cur){
    if(cur != index){
      start = start.getNext();
      return getHelper(start, index, cur+1);
    }
    return start;
  }

  @Override
  public void remove(T elem) {
      //TODO: Implement this method.
      if(elem == null){
        throw new NullPointerException();
      }
      if(elem == getFirst()){
        removeFirst();
      }
      else{
        int index = indexOf(elem);
        if(index == -1){
          throw new ItemNotFoundException();
        }
        Node<T> precNode = getPrec(head, index, 0);
        Node<T> sucNode = getSuc(head, index, 0);
        precNode.setNext(sucNode);
        size--;
      }


  }

  @Override
  public int indexOf(T elem) {
    int index = -1;
      //TODO: Implement this method.
    if(elem == null){
      throw new NullPointerException();
    }
    if(size ==1 && head.getData() != elem){
      return -1;
    }else if(head.getData() == elem){
      return 0;
    }else if(!contains(head, elem)){
      return -1;
    }else{
      index = indexOfHelper(head, elem, 0);
    }
    return index;
  }

  private int indexOfHelper(Node<T> start, T element, int count){
    if(start.getData() != element && start.getNext() != null){
      return indexOfHelper(start.getNext(), element, count+1);
    }
    return count;

  }



  @Override
  public boolean isEmpty() {
    boolean empty = false;
    if(head == null){
      empty = true;
    }
    return empty;
  }


  public Iterator<T> iterator() {
    Iterator<T> iter = null;
      //TODO: Implement this method.

   return iter;
  }

  private boolean contains(Node<T> cur, T elem){
    if(cur == null){
      return false;
    }
    if(cur.getData() == elem){
      return true;
    }
    return contains(cur.getNext(), elem);
  }
}
